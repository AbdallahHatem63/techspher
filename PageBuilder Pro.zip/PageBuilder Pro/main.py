import tkinter as tk
from tkinter import filedialog, colorchooser, simpledialog, messagebox, Toplevel
import webbrowser
from pathlib import Path
import html

# ======================
# Generate Professional HTML
# ======================
def generate_html(page_name, elements, bg):
    body_content = ''
    for elem in elements:
        if elem['type'] == 'text':
            body_content += f'<p style="position:absolute; left:{elem["x"]}px; top:{elem["y"]}px; font-family:{elem["font"]}; font-size:{elem["size"]}px; color:{elem.get("color","#000")}; background:{elem.get("bg","transparent")};">{html.escape(elem["text"])}</p>\n'
        elif elem['type'] == 'button':
            body_content += f'<button style="position:absolute; left:{elem["x"]}px; top:{elem["y"]}px; padding:{elem["padding"]}; background:{elem["color"]}; color:#fff; border:none; border-radius:{elem.get("radius",10)}px; cursor:pointer; font-family:{elem.get("font","Arial")};" onclick="window.location.href=\'{elem.get("link","#")}\';">{html.escape(elem["text"])}</button>\n'
        elif elem['type'] == 'image':
            body_content += f'<img src="{elem["path"]}" style="position:absolute; left:{elem["x"]}px; top:{elem["y"]}px; max-width:{elem.get("width",200)}px; max-height:{elem.get("height",200)}px; border-radius:{elem.get("radius",0)}px; border:{elem.get("border","none")};">\n'
        elif elem['type'] == 'video':
            body_content += f'<video src="{elem["path"]}" autoplay loop muted style="position:absolute; left:{elem["x"]}px; top:{elem["y"]}px; width:{elem.get("width",300)}px; height:{elem.get("height",200)}px; border-radius:{elem.get("radius",0)}px; border:{elem.get("border","none")};"></video>\n'
        elif elem['type'] in ['login','signup','login_custom']:
            body_content += f'<div style="position:absolute; left:{elem["x"]}px; top:{elem["y"]}px; width:{elem["width"]}px; padding:15px; background:{elem.get("bg","#eee")}; border-radius:10px;">\n'
            for input_field in elem['fields']:
                body_content += f'<input type="{input_field["type"]}" placeholder="{input_field["placeholder"]}" style="width:100%; margin-bottom:5px; padding:5px;"><br>\n'
            body_content += f'<button style="width:100%; background:{elem.get("btn_color")}; color:#fff; border:none; padding:10px; border-radius:10px;">{elem.get("btn_text")}</button></div>\n'

    html_code = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(page_name)}</title>
<style>
body {{ background:{bg}; margin:0; font-family:Arial; position:relative; width:1200px; height:800px; overflow:hidden; }}
button:hover {{ transform:scale(1.05); opacity:0.85; transition:0.3s; }}
</style>
</head>
<body>
{body_content}
</body>
</html>'''
    return html_code

# ======================
# Main Program
# ======================
class PageBuilder(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🔥 Professional HTML Page Builder")
        self.geometry("1400x800")
        self.minsize(800,600)
        self.resizable(True, True)

        self.bg_color = '#ffffff'
        self.btn_color = '#2196f3'
        self.selected_font = 'Arial'

        # Top Frame
        top_frame = tk.Frame(self, height=50, bg="#eee")
        top_frame.pack(side="top", fill="x")
        tk.Label(top_frame, text="Page Name:").pack(side="left", padx=5)
        self.page_name_entry = tk.Entry(top_frame)
        self.page_name_entry.pack(side="left", padx=5)
        tk.Button(top_frame, text="Create Page", bg="#4caf50", fg="#fff", command=self.create_page).pack(side="right", padx=5)
        tk.Button(top_frame, text="Exit", bg="#f44336", fg="#fff", command=self.destroy).pack(side="right", padx=5)
        tk.Button(top_frame, text="Templates", bg="#2196f3", fg="#fff", command=self.open_templates).pack(side="right", padx=5)

        # Left Panel
        self.left_frame = tk.Frame(self, width=300, bg="#f5f5f5")
        self.left_frame.pack(side="left", fill="y", padx=5, pady=5)

        # Colors
        tk.Label(self.left_frame, text="Background Color:").pack(pady=5)
        tk.Button(self.left_frame, text="Choose Color", command=self.choose_bg).pack(pady=5)
        tk.Label(self.left_frame, text="Button Color:").pack(pady=5)
        tk.Button(self.left_frame, text="Choose Color", command=self.choose_btn).pack(pady=5)

        # Fonts
        tk.Label(self.left_frame, text="Fonts:").pack(pady=5)
        fonts = ["Arial","Times New Roman","Comic Sans MS","Tahoma","Verdana"]
        for f in fonts:
            tk.Button(self.left_frame, text=f, font=(f,14), command=lambda ff=f: self.select_font(ff)).pack(pady=2, fill="x")

        # Elements
        tk.Label(self.left_frame, text="Elements:").pack(pady=10)
        elements = [
            ("Text", self.add_text), 
            ("Button", self.add_button), 
            ("Image", self.add_image), 
            ("Video", self.add_video), 
            ("Login Form", self.add_login),
            ("Signup Form", self.add_signup),
            ("Custom Login", self.add_login_custom)
        ]
        for name, cmd in elements:
            tk.Button(self.left_frame, text=name, width=20, command=cmd).pack(pady=5)

        # Canvas
        self.canvas_frame = tk.Frame(self, bg="#fff")
        self.canvas_frame.pack(side="right", fill="both", expand=True, padx=5, pady=5)
        self.canvas = tk.Canvas(self.canvas_frame, bg="#fff")
        self.canvas.pack(fill="both", expand=True)

        # Element List
        self.elements_on_canvas = []
        self.selected_item = None
        self.offset_x = 0
        self.offset_y = 0
        self.canvas.bind("<Button-1>", self.select_item)
        self.canvas.bind("<B1-Motion>", self.move_item)
        self.canvas.bind("<Button-3>", self.delete_item)

        # Bind canvas resize
        self.canvas.bind("<Configure>", self.on_canvas_resize)

    # ===== Color & Font =====
    def choose_bg(self):
        color = colorchooser.askcolor()[1]
        if color: self.bg_color = color; self.canvas.config(bg=color)

    def choose_btn(self):
        color = colorchooser.askcolor()[1]
        if color: self.btn_color = color

    def select_font(self, font_name):
        self.selected_font = font_name

    # ===== Add Elements =====
    def add_text(self):
        x, y = 50,50
        text = simpledialog.askstring("Text","Enter text:")
        if not text: return
        size = 16
        color = '#000'
        item = self.canvas.create_text(x,y,text=text,anchor='nw',font=(self.selected_font,size), fill=color)
        self.elements_on_canvas.append({"type":"text","item":item,"text":text,"x":x,"y":y,"font":self.selected_font,"size":size,"color":color,"bg":"transparent"})

    def add_button(self):
        x, y = 50,50
        text = simpledialog.askstring("Button","Enter button text:")
        if not text: return
        item = self.canvas.create_rectangle(x,y,x+120,y+40,fill=self.btn_color)
        text_item = self.canvas.create_text(x+60,y+20,text=text,fill='#fff', font=(self.selected_font,12))
        self.elements_on_canvas.append({"type":"button","item":item,"text_item":text_item,"text":text,"x":x,"y":y,"padding":"10px 20px","color":self.btn_color,"link":"#","radius":10,"font":self.selected_font})

    def add_image(self):
        path = filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg *.gif *.webp")])
        if not path: return
        x, y = 50,50
        img = tk.PhotoImage(file=path)
        item = self.canvas.create_image(x,y,image=img,anchor='nw')
        self.elements_on_canvas.append({"type":"image","item":item,"path":path,"x":x,"y":y,"width":200,"height":200,'image':img,'radius':0,'border':'none'})

    def add_video(self):
        path = filedialog.askopenfilename(filetypes=[("Videos","*.mp4 *.webm *.ogg")])
        if not path: return
        x,y=50,50
        self.elements_on_canvas.append({"type":"video","path":path,"x":x,"y":y,"width":300,"height":200,'radius':0,'border':'none'})

    def add_login(self):
        x,y=50,50
        self.elements_on_canvas.append({"type":"login","x":x,'y':y,'width':250,'btn_color':self.btn_color,'bg':'#eee','btn_text':'Login','fields':[{'type':'text','placeholder':'Email'},{'type':'password','placeholder':'Password'}]})

    def add_signup(self):
        x,y=50,50
        self.elements_on_canvas.append({"type":"signup","x":x,'y':y,'width':250,'btn_color':'#4caf50','bg':'#eee','btn_text':'Sign Up','fields':[{'type':'text','placeholder':'Name'},{'type':'text','placeholder':'Email'},{'type':'password','placeholder':'Password'}]})

    def add_login_custom(self):
        x,y=50,50
        self.elements_on_canvas.append({"type":"login_custom","x":x,'y':y,'width':360,'btn_color':'linear-gradient(90deg, #ff0050, #ff7f00)','bg':'rgba(30,30,30,0.85)','btn_text':'Login','fields':[{'type':'text','placeholder':'Username'},{'type':'password','placeholder':'Password'}]})

    # ===== Move & Delete =====
    def select_item(self,event):
        items = self.canvas.find_overlapping(event.x,event.y,event.x,event.y)
        self.selected_item = None
        for elem in self.elements_on_canvas:
            if elem.get('item') in items or elem.get('text_item') in items:
                self.selected_item = elem
                self.offset_x = event.x - elem.get('x',0)
                self.offset_y = event.y - elem.get('y',0)
                break

    def move_item(self,event):
        if not self.selected_item: return
        x = event.x - self.offset_x
        y = event.y - self.offset_y
        self.selected_item['x'] = x
        self.selected_item['y'] = y
        if self.selected_item['type']=='text':
            self.canvas.coords(self.selected_item['item'], x, y)
        elif self.selected_item['type']=='button':
            self.canvas.coords(self.selected_item['item'], x, y, x+120, y+40)
            self.canvas.coords(self.selected_item['text_item'], x+60, y+20)
        elif self.selected_item['type']=='image':
            self.canvas.coords(self.selected_item['item'], x, y)

    def delete_item(self,event):
        items = self.canvas.find_overlapping(event.x,event.y,event.x,event.y)
        for elem in self.elements_on_canvas[:]:
            if elem.get('item') in items or elem.get('text_item') in items:
                if elem.get('item'): self.canvas.delete(elem['item'])
                if elem.get('text_item'): self.canvas.delete(elem['text_item'])
                self.elements_on_canvas.remove(elem)
                break

    # ===== Canvas Resize =====
    def on_canvas_resize(self, event):
        self.canvas.config(width=event.width, height=event.height)

    # ===== Create Page =====
    def create_page(self):
        page_name = self.page_name_entry.get() or "MyPage"
        html_code = generate_html(page_name, self.elements_on_canvas, self.bg_color)
        path = Path("page.html")
        path.write_text(html_code, encoding='utf-8')
        webbrowser.open(path.resolve())
        messagebox.showinfo("Success", "Page created and opened in your browser!")

    # ===== Templates =====
    def open_templates(self):
        tpl_window = Toplevel(self)
        tpl_window.title("Templates")
        tpl_window.geometry("400x500")
        templates = ["Basic Login","Basic Signup","Professional Button","Sample Text","Custom Login"]
        for tpl in templates:
            tk.Button(tpl_window,text=tpl,width=30,command=lambda t=tpl: self.load_template(t)).pack(pady=5)

    def load_template(self,name):
        if name=="Basic Login":
            self.add_login()
        elif name=="Basic Signup":
            self.add_signup()
        elif name=="Professional Button":
            self.add_button()
        elif name=="Sample Text":
            self.add_text()
        elif name=="Custom Login":
            self.add_login_custom()
        messagebox.showinfo("Done", f"Template added: {name}")

if __name__=="__main__":
    app = PageBuilder()
    app.mainloop()
